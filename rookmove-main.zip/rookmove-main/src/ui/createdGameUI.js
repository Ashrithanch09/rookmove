export default function createdGameUI(roomCode) {
	return `
	<h1>Waiting for Player 2</h1>
	Game Code: ${roomCode}
	`
}
