import "./style.css"
import Phaser from "./src/Phaser"
import initUI from "./src/ui/initUI"

// Initialize UI
initUI()
